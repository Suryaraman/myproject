package constructor;

public class Person {
	public static void main(String[] args) {
		Constructor c=new Constructor();
		Constructor cu=new Constructor(2);
		Constructor c1=new Constructor(123,"surya");
		c1.person();
	}

}
