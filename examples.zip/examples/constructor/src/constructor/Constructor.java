package constructor;

public class Constructor {
	String name;
	int id;
	Constructor(){
		System.out.println("Constructor with no parameter");
	}
	Constructor(int a){
		System.out.println("Constructor with parameter");			
	}
	Constructor(int id,String name){
		this.id=id;
		this.name=name;
	}
	public void person() {
		System.out.println("my id is "+id);
		System.out.println("my name is "+name);
	
	}
	
}
