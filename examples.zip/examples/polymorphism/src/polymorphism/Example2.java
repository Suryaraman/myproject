package polymorphism;

public class Example2 extends Example1 {
	public void shop() {
		System.out.println("we are selling magazines");
		}

}
