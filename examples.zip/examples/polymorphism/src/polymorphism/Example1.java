package polymorphism;

/*public class Example1 {
	public void shop() {
		System.out.println("we are selling books");
		}
	public int payment() {
		System.out.println("payment through card");	
		return 0;
	}
	public int payment(int a) {
		System.out.println("payment through cash");	
		return 1;
	}

}*/

			//valid methods of overloading are below:

/*public class Example1 {
	public void shop() {
		System.out.println("we are selling books");
		}
	public int payment(int a,int b) {
		System.out.println("payment through card");	
		return 0;
	}
	public int payment(int a,int b,int c) {
		System.out.println("payment through cash");	
		return 1;
	}

}*/

			//valid methods of overloading are below:
/*public class Example1 {
	public void shop() {
		System.out.println("we are selling books");
		}
	public int payment(int a,int b) {
		System.out.println("payment through card");	
		return 0;
	}
	public int payment(int a,int b,float c) {
		System.out.println("payment through cash");	
		return 1;
	}

}*/


			//valid methods of overloading are below:

/*public class Example1 {
	public void shop() {
		System.out.println("we are selling books");
		}
	public int payment(int a,float b) {
		System.out.println("payment through card");	
		return 0;
	}
	public int payment(float a,int b) {
		System.out.println("payment through cash");	
		return 1;
	}

}*/

			//valid methods of overloading by changing return type of method:


public class Example1 {
	public void shop() {
		System.out.println("we are selling books");
		}
	public int payment(int a,float b) {
		System.out.println("payment through card");	
		return 0;
	}
	public float payment(float a,int b) {
		System.out.println("payment through cash");	
		return 1;
	}

}


