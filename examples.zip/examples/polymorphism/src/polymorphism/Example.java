package polymorphism;

public class Example {
	void signup(String name,int id) {
		System.out.println("Name "+name+ "ID"+id);		
	}
}
	public class Login extends Example {
		void signup(String name,int id) {
			System.out.println("Name "+name+ "ID"+id);		
		}
	}
		public class Signup{
			Public Static void main(String[] args) {
				Login lo = new Login();
				lo.signup(surya,27);
			}
		}



