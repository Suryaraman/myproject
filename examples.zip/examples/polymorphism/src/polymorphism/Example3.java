package polymorphism;

/*public class Example3 {
	public static void main(String[] args) {
		Example2 ex=new Example2();
		ex.shop();
		Example1 ex1=new Example1();
		ex1.payment();
		ex1.payment(2);
		ex1.shop();
		Example1 ob=new Example2();
		ob.shop();
		
	}

}*/


/*public class Example3 {
	public static void main(String[] args) {
		Example2 ex=new Example2();
		ex.shop();
		Example1 ex1=new Example1();
		ex1.payment(1,2);
		ex1.payment(1,2,3);
		ex1.shop();
		Example1 ob=new Example2();
		ob.shop();
		
	}

}*/


/*public class Example3 {
	public static void main(String[] args) {
		Example2 ex=new Example2();
		ex.shop();
		Example1 ex1=new Example1();
		ex1.payment(1,2);
		ex1.payment(1,2,2.1f);
		ex1.shop();
		Example1 ob=new Example2();
		ob.shop();
		
	}

}*/



public class Example3 {
	public static void main(String[] args) {
		Example2 ex=new Example2();
		ex.shop();
		Example1 ex1=new Example1();
		ex1.payment(1,2.1f);
		ex1.payment(1.1f,2);
		ex1.shop();
		Example1 ob=new Example2();
		ob.shop();
		
	}

}

