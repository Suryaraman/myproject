package inheritance;

/*public class Cat extends Cow {
	void talk() {
		System.out.println("cat sounds meow..");
	}

}*/ //multilevel inheritance
public class Cat extends Animal {
	void talk() {
		System.out.println("cat sounds meow..");
	}

}
// type of hierarchical type