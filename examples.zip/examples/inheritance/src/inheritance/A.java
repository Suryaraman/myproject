package inheritance;

	public class A {
		public int add(int a,int b) {return a+b;}
		static int sub(int x,int y,int z) {return x-y-z;
					
		}
	}
		