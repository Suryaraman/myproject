package inheritance;

public class Animal {
	void sound() {
		System.out.println("animal sounds : ");
	}
}
