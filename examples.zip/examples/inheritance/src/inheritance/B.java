package inheritance;

public class B extends A {
	public int add(int a,int b) {return a+b;}
	static int sub(int x,int y) {return x-y;}
	public static void main(String[] args){
		B b=new B();
	System.out.println(b.add(2,2));
	System.out.println(sub(2,2));
 
	}
}
	
