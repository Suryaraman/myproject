package inheritance;

public class Cow extends Animal {
	void sounds() {
		System.out.println("cow sounds maaa..");
	}
}
