package inheritance;

/*public class Main {
	public static void main(String[] args) {
		Cat c=new Cat();
		c.sound();
		c.sounds();
		c.talk();
	}

}*/ //type of multilevel inheritance

public class Main {
	public static void main(String[] args) {
		Cat c=new Cat();
		c.sound();
		c.talk();
		Cow co=new Cow();
		co.sounds();
		co.sound();
	}

}
//type of hierarchical type