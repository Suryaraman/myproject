
public class Interface1 implements Interface {
	public void A() {
		System.out.println("hiiii");
	}
	public void B() {
		System.out.println("hello");
		
	}
	public static void main(String[] args) {
		Interface1 in=new Interface1();
		in.A();
		in.B();
		System.out.println(x);
	}

}
