
public interface Interface {
	public void A();
	abstract public void B();
	int x=10;
	

}
