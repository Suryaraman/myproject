package abstraction;

public class Bmw extends Abstraction {
	public void sound() {
		System.out.println("Its roaring..");
	}

}
