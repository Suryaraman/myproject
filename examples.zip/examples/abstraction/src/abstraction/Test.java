package abstraction;

public class Test {
	public static void main(String[] args) {
		Abstraction ab=new Bmw();
		ab.car();
		ab.sound();
	}

}
