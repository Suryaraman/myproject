package encapsulation;

public class Bank {
	public static void main(String[] args) {
		Encapsulation ep= new Encapsulation();
		ep.setName("surya");
		ep.setId("kamesh");
		ep.setPassword("xyz");
		System.out.println("enter name: "+ep.getName());
		System.out.println("enter Id: "+ep.getId());
		System.out.println("enter Password: "+ep.getPassword());
	}

}
