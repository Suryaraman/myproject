package encapsulation;

public class Encapsulation {
	private String name;
	private int id;
	private String password;
	public String getName()
	{
		return name;
	}
	public int getId()
	{
		return id;
	}
	public String getPassword()
	{
		return password;
	}
	public String setName(String pswd)
	{
		return this.name=pswd;
	}
	public int setId(int Id)
	{
		return this.id=Id;
	}
	public String setPassword(String pswd)
	{
		return this.password=pswd;
	}
	
	
	

}
